## Car Rental System

<img src = "https://github.com/Ellie-Y/CarRentalSystem/blob/master/presentation.gif" width = "800px" />



This project used Qt creator 5.8.0, and it divided into 8 classes, the start one is login class.


- The class of Sign_In implement the function of  sign-up. (I made a typo)

- It includes database, please use absolute path of your database in the "connectData" method, which located in Login, Sign_In and findRidePage classes.
